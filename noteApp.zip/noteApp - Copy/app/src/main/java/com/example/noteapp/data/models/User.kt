package com.example.noteapp.data.models

data class User(
    val uid : String? = null,
    val name : String? = null,
    val email : String? = null,
)